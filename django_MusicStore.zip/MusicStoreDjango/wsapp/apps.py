from django.apps import AppConfig


class WsappConfig(AppConfig):
    name = 'wsapp'
