

export class GrowthChart {
  x: string;
  y: number;
}
