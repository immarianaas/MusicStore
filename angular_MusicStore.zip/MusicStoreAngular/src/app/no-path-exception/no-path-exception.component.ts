import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-path-exception',
  templateUrl: './no-path-exception.component.html',
  styleUrls: ['./no-path-exception.component.css']
})
export class NoPathExceptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
