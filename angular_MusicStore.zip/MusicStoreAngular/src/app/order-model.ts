
export class OrderModel {
  address: number;
  payment: string;

  constructor() {
    this.address = -1;
    this.payment = '';
  }
}
