
export class Address {
  id: number;
  street: string;
  city: string;
  code: string;
  country: string;
  door: number;

  person: Account;

}
