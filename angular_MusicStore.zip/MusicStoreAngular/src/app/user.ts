/*
export class AuthUser {
  username: string;
  password: string;
}*/

export class User {
  username: string;
  password: string;
  date_joined: string;

}
